/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.practica_evaluada_3_javierretana;

import javax.swing.JOptionPane;

/**
 *
 * @author jareg
 */
public class Practica_Evaluada_3_JavierRetana {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        //Nombres de los productos
        String[] productos = {"arroz", "carne", "queso", "huevos"};

        //Matriz de ventas
        int[][] ventas = {
            {2, 5, 1, 3},
            {5, 2, 3, 4},
            {1, 2, 1, 3},
            {5, 6, 1, 2},
            {1, 3, 2, 4},
            {2, 3, 1, 5},
            {7, 2, 4, 1}
        };
        int N = 0;
        int[] totalVentasProducto = new int[N];
        for (int j = 0; j < N; j++) {
            for (int i = 0; i < 7; i++) {
                totalVentasProducto[j] += ventas[i][j];
            }
        }
        //Dia con Mayores Ventas
        int VentasDia = 0;
        int Dia = 0;
        for (int i = 0; i < 7; i++) {
            int totalDia = 0;
            for (int j = 0; j < N; j++) {
                totalDia += ventas[i][j];
            }
            if (totalDia > VentasDia) {
                VentasDia = i;
            }
        }
        //Producto mas Vendido
        int VentasProducto = 0;
        int ProductoMasVendido = 0;
        for (int j = 0; j < N; j++) {
            if (totalVentasProducto[j] > VentasProducto) {
                VentasProducto = totalVentasProducto[j];
                ProductoMasVendido = j;
            }
        }
        //Msotrar Resultados

         String resultado = "Total de ventas por producto:\n";
        for (int j = 0; j < N; j++) {
            resultado = resultado + productos[j] + ": " + totalVentasProducto[j] + "\n";
        }
        String[] dias = null;
        int indiceDiaMax = 0;

        resultado = resultado + "\nEl día con mayores ventas totales es " + dias[indiceDiaMax] + 
                    " con " + VentasDia + " ventas.\n";
        int indiceProductoMax = 0;
        resultado = resultado + "El producto más vendido durante la semana es: " + productos[indiceProductoMax] + 
                    " con " + VentasProducto + " ventas.";

        JOptionPane.showMessageDialog(null, resultado);
    }
}
    

    

